#include <stdlib.h>
#include <sds_incl.h>
#include "cf_stub.h"

cf_request_handle_t _p0_request_0;
cf_request_handle_t _p0_request_1;
cf_request_handle_t _p0_request_2;
cf_request_handle_t _p0_request_3;
cf_request_handle_t _p0_request_4;
cf_request_handle_t _p0_request_5;

size_t _p0_sharpen_filter_0_num_output_r;
size_t _p0_sharpen_filter_0_num_ap_return;
size_t _p0_sobel_filter_0_num_output_r;
size_t _p0_sobel_filter_0_num_ap_return;

