#ifndef STUBS_H_
#define STUBS_H_

#include "sds_incl.h"
#include "portinfo.h"
#include "accel_info.h"
#include "sds_lib.h"

extern cf_request_handle_t _p0_request_0;
extern cf_request_handle_t _p0_request_1;
extern cf_request_handle_t _p0_request_2;

extern size_t _p0_sharpen_filter_0_num_output_r;
extern size_t _p0_sharpen_filter_0_num_ap_return;



#endif
