# 1 "C:/xup/SDSoC/labs/lab5a/src/sharpen.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 319 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "C:/xup/SDSoC/labs/lab5a/src/sharpen.c" 2







# 1 "C:/xup/SDSoC/labs/lab5a/src/lab_design.h" 1
# 12 "C:/xup/SDSoC/labs/lab5a/src/lab_design.h"
# 1 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\inttypes.h" 1
# 25 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\inttypes.h"
# 1 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\features.h" 1
# 343 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\features.h"
# 1 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\stdc-predef.h" 1
# 344 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\features.h" 2
# 365 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\features.h"
# 1 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\sys/cdefs.h" 1
# 402 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\sys/cdefs.h"
# 1 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\bits/wordsize.h" 1
# 403 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\sys/cdefs.h" 2
# 366 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\features.h" 2
# 389 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\features.h"
# 1 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\gnu/stubs.h" 1






# 1 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\gnu/stubs-soft.h" 1
# 8 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\gnu/stubs.h" 2
# 390 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\features.h" 2
# 26 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\inttypes.h" 2

# 1 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/lib/gcc/arm-xilinx-linux-gnueabi/4.9.2/include\\stdint.h" 1








# 1 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\stdint.h" 1
# 26 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\stdint.h"
# 1 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\bits/wchar.h" 1
# 27 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\stdint.h" 2
# 1 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\bits/wordsize.h" 1
# 28 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\stdint.h" 2








typedef signed char int8_t;
typedef short int int16_t;
typedef int int32_t;



__extension__
typedef long long int int64_t;




typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;

typedef unsigned int uint32_t;





__extension__
typedef unsigned long long int uint64_t;






typedef signed char int_least8_t;
typedef short int int_least16_t;
typedef int int_least32_t;



__extension__
typedef long long int int_least64_t;



typedef unsigned char uint_least8_t;
typedef unsigned short int uint_least16_t;
typedef unsigned int uint_least32_t;



__extension__
typedef unsigned long long int uint_least64_t;






typedef signed char int_fast8_t;





typedef int int_fast16_t;
typedef int int_fast32_t;
__extension__
typedef long long int int_fast64_t;



typedef unsigned char uint_fast8_t;





typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
__extension__
typedef unsigned long long int uint_fast64_t;
# 125 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\stdint.h"
typedef int intptr_t;


typedef unsigned int uintptr_t;
# 137 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\stdint.h"
__extension__
typedef long long int intmax_t;
__extension__
typedef unsigned long long int uintmax_t;
# 10 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/lib/gcc/arm-xilinx-linux-gnueabi/4.9.2/include\\stdint.h" 2
# 28 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\inttypes.h" 2






typedef unsigned int __gwchar_t;
# 280 "C:/Xilinx/SDSoC/2015.4/SDK/2015.4/gnu/arm/nt/arm-xilinx-linux-gnueabi/libc/usr/include\\inttypes.h"
typedef struct
  {
    __extension__ long long int quot;
    __extension__ long long int rem;
  } imaxdiv_t;





extern intmax_t imaxabs (intmax_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern imaxdiv_t imaxdiv (intmax_t __numer, intmax_t __denom)
      __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern intmax_t strtoimax (const char *__restrict __nptr,
      char **__restrict __endptr, int __base) __attribute__ ((__nothrow__ ));


extern uintmax_t strtoumax (const char *__restrict __nptr,
       char ** __restrict __endptr, int __base) __attribute__ ((__nothrow__ ));


extern intmax_t wcstoimax (const __gwchar_t *__restrict __nptr,
      __gwchar_t **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ ));


extern uintmax_t wcstoumax (const __gwchar_t *__restrict __nptr,
       __gwchar_t ** __restrict __endptr, int __base)
     __attribute__ ((__nothrow__ ));
# 12 "C:/xup/SDSoC/labs/lab5a/src/lab_design.h" 2
# 38 "C:/xup/SDSoC/labs/lab5a/src/lab_design.h"
typedef union pixel {
 struct {
  uint8_t red;
  uint8_t green;
  uint8_t blue;
 };
 struct {
  uint8_t gray;
 };
} pixel_t;

typedef struct frame {
 uint32_t height;
 uint32_t width;
 uint8_t *colorFrame;
 uint8_t *grayFrame;
} frame_t;
# 9 "C:/xup/SDSoC/labs/lab5a/src/sharpen.c" 2
# 1 "C:/xup/SDSoC/labs/lab5a/src/sharpen.h" 1
# 14 "C:/xup/SDSoC/labs/lab5a/src/sharpen.h"
#pragma SDS data buffer_depth(input:2073600, output:2073600)
int sharpen_filter(uint8_t *input, uint8_t *output);
# 10 "C:/xup/SDSoC/labs/lab5a/src/sharpen.c" 2
# 21 "C:/xup/SDSoC/labs/lab5a/src/sharpen.c"
typedef uint8_t window_t[3][3];
typedef uint8_t linebuffer_t[3][1920];


static unsigned char sharpen_operator(window_t window);
static void linebuffer_shift_up(linebuffer_t M, int col);
static uint8_t linebuffer_getval(linebuffer_t M, int RowIndex, int ColIndex);
static void linebuffer_insert_bottom(linebuffer_t M, uint8_t value, int col);
static void window_shift_right(window_t M);
static void window_insert(window_t M, uint8_t value, int row, int col);
static uint8_t window_getval(window_t M, int RowIndex, int ColIndex);


static unsigned char sharpen_operator(window_t window) {
 short x_weight = 0;

 short edge_weight;
 unsigned char edge_val;

 int i;
 int j;

 const short x_op[3][3] = { { 0, -1, 0 }, { -1, 5, -1 },
   { 0, -1, 0 } };


 for (i = 0; i < 3; i++) {
  for (j = 0; j < 3; j++) {

   x_weight = x_weight + (window_getval(window, i, j) * x_op[i][j]);
  }
 }

 edge_weight = ((x_weight>0)? x_weight : -x_weight);

 edge_val = (unsigned char) edge_weight;

 return edge_val;
}



int sharpen_filter(uint8_t *input, uint8_t *output) {

#pragma AP INTERFACE ap_fifo port=input depth=2073600
#pragma AP INTERFACE ap_fifo port=output depth=2073600

 int row;
 int col;
 int index = 0;

 linebuffer_t buff_A;
 window_t buff_C;

 for (row = 0; row < 1080 + 1; row++) {
  for (col = 0; col < 1920 + 1; col++) {

#pragma AP PIPELINE II = 1


 unsigned short input_data = 0;
   unsigned char temp = 0;
   unsigned char tempx = 0;


   if (col < 1920) {
    linebuffer_shift_up(buff_A, col);
    temp = linebuffer_getval(buff_A, 0, col);
   }



   if ((col < 1920) & (row < 1080)) {
    unsigned char y;
    index = row * 1920 + col;
    input_data = input[index];
    y = input_data >> 0;
    tempx = y;
    linebuffer_insert_bottom(buff_A, tempx, col);
   }


   window_shift_right(buff_C);



   if (col < 1920) {
    window_insert(buff_C, linebuffer_getval(buff_A, 2, col), 0, 2);
    window_insert(buff_C, temp, 1, 2);
    window_insert(buff_C, tempx, 2, 2);
   }

   unsigned char edge;



   edge = sharpen_operator(buff_C);



   if (row > 0 && col > 0) {
    index = (row - 1) * 1920 + (col - 1);
    output[index] = (edge << 0) | 0;
   }
  }
 }
 return 0;
}





static void linebuffer_shift_up(linebuffer_t M, int col) {
#pragma AP inline
 int i;
 for (i = 3 - 1; i > 0; i--) {
#pragma AP unroll
 M[i][col] = M[i - 1][col];
 }
}




static uint8_t linebuffer_getval(linebuffer_t M, int RowIndex, int ColIndex) {
#pragma AP inline

 uint8_t return_value;
 return_value = M[RowIndex][ColIndex];
 return return_value;
}





static void linebuffer_insert_bottom(linebuffer_t M, uint8_t value, int col) {
#pragma AP inline

 M[0][col] = value;
}





static void window_shift_right(window_t M) {
#pragma AP inline
 int i, j;
 for (i = 0; i < 3; i++) {
#pragma AP unroll
 for (j = 0; j < 3 - 1; j++) {
#pragma AP unroll
 M[i][j] = M[i][j + 1];
  }
 }
}




static void window_insert(window_t M, uint8_t value, int row, int col) {
#pragma AP inline
 M[row][col] = value;
}




static uint8_t window_getval(window_t M, int RowIndex, int ColIndex) {
#pragma AP inline
 uint8_t return_value;
 return_value = M[RowIndex][ColIndex];
 return return_value;
}
