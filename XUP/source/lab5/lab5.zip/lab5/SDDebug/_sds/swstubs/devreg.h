#ifndef _SDS_DEVREG_H
#define _SDS_DEVREG_H
/* File: C:/xup/SDSoC/labs/lab5/SDDebug/_sds/p0/.cf_work/devreg.h */
#ifdef __cplusplus
extern "C" {
#endif

void _p0_cf_register(int);
void _p0_cf_unregister(int);
#ifdef __cplusplus
};
#endif
#endif /* _SDS_DEVREG_H_ */
